using StudentServiceLib;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Score8_Should_ReturnA()
        {
            Student s = new Student();
            s.Id = 1;
            s.Name = "Toan";
            s.Age = 30;
            s.Score = 8;

            char letter = s.getLetterScore();
            Assert.AreEqual('A', letter);
        }

        [TestMethod]
        [DataRow(2,"Han",30,8,'A')]
        [DataRow(3, "Han", 30, 7,'B')]
        [DataRow(4, "Han", 30, 6,'B')]
        [DataRow(5, "Han", 30, 5,'C')]
        public void Test_LetterScore(int Id,String Name, int Age, double Score, char answer)
        {
            Student s = new Student();
            s.Id = Id;
            s.Name = Name;
            s.Age = Age;
            s.Score = Score;

            char letter = s.getLetterScore();
            Assert.AreEqual(answer, letter);
        }

        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void Check_Valid_Score()
        {
            Student s = new Student();
            s.Id = 1;
            s.Name = "Hoang";
            s.Age = 20;
            s.Score = 11;
        }



    }
}